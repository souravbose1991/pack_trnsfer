from .binning_scenarios import SBOptimalBinning


__all__ = ['SBOptimalBinning']
